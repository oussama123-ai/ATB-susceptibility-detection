import matplotlib.pyplot as plt
import SEG
from .image import subimage_by_roi

default = {
    "artist": {
        'fill': False,
        'ls': '--'},
}


def apply_custom_defaults(d, default_key):
    for k, v in default[default_key].items():
        if k not in d:
            d[k] = v
    

def draw_petri_dish(petri, ax=None):
    bb = petri.boundingBox
    # DRAW CENTER
    # ax.plot(*bb.center, 'or')

    if ax is None:
        ax = plt.gca()

    if petri.isRound:
        art = plt.Circle(petri.center, petri.radius, fill=None, ec='r', ls='--')
        ax.add_artist(art)
    else:
        draw_roi(bb, ax)


def draw_roi(roi, ax, text="", ec='r', text_color='w', text_args={}, rect_args={}):
    apply_custom_defaults(rect_args, "artist")

    rect_args["ec"] = ec
    text_args["color"] = text_color

    rect = plt.Rectangle((roi.x, roi.y), roi.width, roi.height, **rect_args)
    ax.add_artist(rect)

    if text != "":
        text = plt.text(roi.x, roi.bottom, text, **text_args)
        ax.add_artist(text)


def draw_ast(ast, ax, **kwargs):
    """Draw an AST and the analysis results.

    options:
        atb_labels  draw a label for each antibiotic disk
        values:
            'atb' : display antibiotic label
            'number' : displat antibiotic number
            'all' (default) both atb and number
            'off' : do not draw labels
    """
    atb_labels = kwargs.get("atb_labels", 'all')
    ax.imshow(ast.crop)
    for j in range(len(ast.circles)):
        center = ast.circles[j].center
        pellet_r = SEG.config.Pellets_DiamInMillimeters/2
        temp = (center[0]-pellet_r*ast.px_per_mm,
                center[1]-pellet_r*ast.px_per_mm)
        s = f"{j}"
        if atb_labels != 'off':
            bbox = dict(boxstyle="square", ec=(0, 1, 0.5), fc=(0.2, 0.6, 0.2, 0.7))
            atb_label_text = ""
            if atb_labels == 'number':
                atb_label_text = s
            elif atb_labels == 'atb':
                atb_label_text = f"{ast.labels[j].text}"
            elif atb_labels == 'all':
                atb_label_text = f"{s}:{ast.labels[j].text}"
            text = plt.Text(*temp, atb_label_text, color='w', bbox=bbox)
            ax.add_artist(text)

        center = ast.circles[j].center
        inhib_disk = SEG.measureOneDiameter(ast.preproc, j)
        diam = inhib_disk.diameter
        conf = inhib_disk.confidence

        if conf < 1:
            color = 'r'
        else:
            color = 'c'
        circle = plt.Circle(center, diam/2*ast.px_per_mm,
                            ec=color, fc='none', ls='--', alpha=1)
        ax.add_artist(circle)


def draw_antibiotic(atb, ax):
    ax.imshow(atb.img)
    diam = atb.inhibition.diameter
    r = diam/2*atb.px_per_mm
    cx, cy = atb.center_in_roi
    circle = plt.Circle((cx, cy), r, fill=False, ec='c', ls='--')
    ax.add_artist(circle)


def dess(obj, ax=None, **kwargs):
    if ax is None:
        ax = plt.gca()

    if isinstance(obj, SEG.Roi):
        draw_roi(obj, ax, **kwargs)
    elif isinstance(obj, SEG.AST):
        draw_ast(obj, ax, **kwargs)
    elif isinstance(obj, SEG.Antibiotic):
        draw_antibiotic(obj, ax, **kwargs)
    elif isinstance(obj, SEG.PetriDish):
        draw_petri_dish(obj, ax)
    else:
        raise AttributeError("Don't know how to draw: {}.".format(str(obj)))
